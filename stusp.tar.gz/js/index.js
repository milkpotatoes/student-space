//动态设置背景图显示位置
function setBG() {
	let ew = document.getElementsByClassName("background-card")[0].offsetWidth;
	let eh = document.getElementsByClassName("background-card")[0].offsetHeight;
	let item = document.getElementsByClassName("userBasicInfo")[0].offsetHeight;
	let py = 0 - (ew * 1155 / 2048 + item - eh);
	$(".background-card").css("background-position", `0px ${py}px`);
	// console.log(`元素宽度：${ew}，元素高度:${eh}，信息栏高度：${item}，位移${py}`)
}
// 获取未认领考试数目
function getUnClaimExamCount() {
	$.ajax({
		type: "get",
		url: getUrl("score", "/exam/getExamCount"),
		headers: {
			Version: localStorage.getItem("szoneVersion"),
			Token: localStorage.getItem("Token")
		},
		data: {
			studentName: getUserCache().data.studentName,
			schoolGuid: getUserCache().data.schoolGuid
		},
		success: function(data, status) {
			data = JSON.parse(data);
			if (data.status != 200) {
				mdui.snackbar({
					message: data.message,
					buttonText: "确定",
					onButtonClick: function() {
						window.location.assign("login.html");
					},
					onClose: function() {
						window.location.assign("login.html");
					}
				});
				return false;
			}
			
			if (data.data.unClaimCount > 0) {
				let unClaimCount = data.data.unClaimCount;
				mdui.snackbar({
					message: `你当前有${unClaimCount}场考试待认领`,
					buttonText: "查看",
					onButtonClick: function() {
						window.location.assign("unClaim.html");
					}
				});
				$(".notifications-icon").text("notifications");
			}
		}
	});
}

function getExamList(start, rows) {
	$(".exam-item-pgs").addClass("exam-loading");
	$(".exam-item-pgs").removeClass("exam-more");
	$(".exam-item-pgs").removeClass("mdui-hidden");
	$.ajax({
		type: "get",
		url: getUrl("score", "/exam/getClaimExams"),
		data: {
			studentName: getUserCache().data.studentName,
			schoolGuid: getUserCache().data.schoolGuid,
			start: start,
			rows: rows
		},
		headers: {
			Version: localStorage.getItem("szoneVersion"),
			Token: localStorage.getItem("Token")
		},
		success: function(data, status) {
			data = JSON.parse(data);
			if (data.status != 200) {
				mdui.snackbar({
					message: data.message,
					buttonText: "确定",
					onButtonClick: function() {
						window.location.assign("login.html");
					},
					onClose: function() {
						window.location.assign("login.html");
					}
				});
				return false;
			}

			setTimeout(function() {
				for (let i = 0; i < data.data.list.length; i++) {
					var examData = data.data.list[i];
					let examTime = examData.time.replace(/(\d{4})-(\d{2})-(\d{2})/, "考试时间：$1年$2月$3日");
					let examName = examData.examName;
					let examScore = examData.score;
					let examGuid = examData.examGuid;
					let studentCode = examData.studentCode;
					let examType = examData.type;
					let examItem =
						`<li class="mdui-list-item mdui-card mdui-m-t-1 mdui-hoverable examItem" onclick="examDetails('${examGuid}','${studentCode}')">
					<div class="mdui-list-item-content">
					<div class="mdui-list-item-title"><span class="mdui-text-color-theme-accent">${examType} · </span>${examName}</div>
					<div class="mdui-list-item-text examTime">${examTime}</div>
					</div>
					<i class="mdui-icon mdui-list-item-icon mdui-text-color-theme-accent mdui-m-r-4">${examScore}</i>
					</li>`;
					// console.log(examItem)
					$("#examList").append($(examItem));
				}
				$(".exam-item-pgs").removeClass("exam-loading");
				if ($(".examItem").length >= data.data.total) {
					$(".exam-item-pgs").addClass("exam-end");
					mdui.snackbar({
						message: "已加载全部考试"
					});
					$(".exam-item-pgs").addClass("mdui-hidden");
				} else {
					$(".exam-item-pgs").addClass("exam-more");
				}

				$(".exam-item-pgs").addClass("mdui-hidden");
				if ($(this).scrollTop() + $(this).height() >= $(document).height() && !$(".exam-item-pgs").hasClass("exam-end")) {
					getExamList($(".examItem").length, rows);
				}
			}, 1500);
		}
	});
}
// 打开考试详情页面
function examDetails(examGuid, studentCode) {
	var jumpId = (new Date()).getTime().toString();
	var jumpData = {
		"id": jumpId,
		"examGuid": examGuid,
		"studentCode": studentCode
	};
	sessionStorage.jumpId = jumpId;
	sessionStorage.jumpData = Base64.encode(JSON.stringify(jumpData));
	// window.location.assign(`exam.html?examGuid=${examGuid}&studentCode=${studentCode}`);
	window.location.assign("exam.html");
}

$(function() {
	// 窗口变动监听
	window.onresize = function() {
		setBG();
	};
	if (!localStorage.getItem("Token")) {
		window.location.assign("login.html");
		return false;
	} else {
		// 以本地缓存设置用户信息
		let data = getUserCache();
		// 设置用户头像
		if (data) {
			if (data.data.avarUrl === "") {
				$(".userAvatar").attr("src", "src/ic_launcher.png");
			} else {
				$(".userAvatar").attr("src", data.data.avarUrl);
			}
			$(".nickName").text(data.data.nickName);
			$(".userCode").text((getUserCache().data.userCode).replace(/(\d{3})\d*(\d{4})/, '$1****$2'));
		}
	}
	// 获取用户信息
	getUserInfo(function(data, status) {
		data = JSON.parse(data);
		if (data.status == 200) {
			localStorage.setItem("userInfo", Base64.encode(JSON.stringify(data)));
			// 设置用户头像
			if (data.data.avarUrl === "") {
				$(".userAvatar").attr("src", "src/ic_launcher.png");
			} else {
				$(".userAvatar").attr("src", data.data.avarUrl);
			}
			$(".nickName").text(data.data.nickName);
			$(".userCode").text((getUserCache().data.userCode).replace(/(\d{3})\d*(\d{4})/, '$1****$2'));
			getUnClaimExamCount();
		} else {
			mdui.snackbar({
				message: data.message,
				buttonText: "确定",
				onButtonClick: function() {
					window.location.assign("login.html");
				},
				onClose: function() {
					window.location.assign("login.html");
				}
			});
			return false;
		}
	});

	// 获取考试列表
	setTimeout(function() {
		if ($(this).scrollTop() + $(this).height() >= $(document).height()) {
			if (getUserCache().data.schoolGuid !== undefined) {
				getExamList($(".examItem").length, 8);
			} else {
				mdui.snackbar({
					message: "请先绑定学生信息",
					buttonText: "前往绑定",
					onClose: function() {
						window.location.assign("user.html");
					},
					onButtonClick: function() {
						window.location.assign("user.html");
					},
				});
			}
		}

		$(window).scroll(function() {
			var scrollTop = $(this).scrollTop(); //滚动条距离顶部的高度
			var scrollHeight = $(document).height(); //当前页面的总高度
			var clientHeight = $(this).height(); //当前可视的页面高度
			if (scrollTop + clientHeight >= scrollHeight - 80 && !$(".exam-item-pgs").hasClass("exam-end")) { //距离顶部+当前高度 >=文档总高度 即代表滑动到底部 注：-50 上拉加载更灵敏
				//加载数据
				if (!$(".exam-item-pgs").hasClass("exam-loading") && $(".exam-item-pgs").hasClass("exam-more")) {
					if (getUserCache().data.schoolGuid) {
						getExamList($(".examItem").length, 8);
					} else {
						mdui.snackbar({
							message: "请先绑定学生信息",
							buttonText: "前往绑定",
							onClose: function() {
								window.location.assign("user.html");
							},
							onButtonClick: function() {
								window.location.assign("user.html");
							},
						});
					}
				}
			}
		})
	}, 200)
	
	setBG();
});
