localStorage.setItem("szoneVersion", "3.0.6");

$(function() {
	$(".open-link").click(function(e) {
		window.open($(e.target).closest(".open-link").attr("data"));
	});

	$(".jump-link").click(function(e) {
		window.location.assign($(e.target).closest(".jump-link").attr("data"));
	});

	$(".back-top").addClass("mdui-hidden");
	$(window).scroll(function() {
		if ($(window).scrollTop() > 80) {
			$(".back-top").removeClass("mdui-hidden");
		} else {
			$(".back-top").addClass("mdui-hidden");
		}
	});

	$(".back-top").click(function() {
		$(window).scrollTop(0);
	});
	if (!window.location.href.match(/(\/login\.html)/) & !window.location.href.match(/(\/404\.html)/) & !localStorage.getItem(
			"Token")) {
		mdui.snackbar({
			message: "请登录后重试",
			buttonText: "确定",
			onButtonClick: function() {
				window.location.replace("login.html");
				localStorage.removeItem("userInfo");
				localStorage.removeItem("Token");
			},
			onClose: function() {
				window.location.replace("login.html");
				localStorage.removeItem("userInfo");
				localStorage.removeItem("Token");
			}
		});
	}
	
	sessionStorage.removeItem('jumpId');
	sessionStorage.removeItem('jumpData');
});

var _hmt = _hmt || [];
(function() {
	var hm = document.createElement("script");
	hm.src = "https://hm.baidu.com/hm.js?dd18823003a9883d07ac0b24b75f9d16";
	var s = document.getElementsByTagName("script")[0];
	s.parentNode.insertBefore(hm, s);
})();

(function(b, a, e, h, f, c, g, s) {
	b[h] = b[h] || function() {
		(b[h].c = b[h].c || []).push(arguments);
	};
	b[h].s = !!c;
	g = a.getElementsByTagName(e)[0];
	s = a.createElement(e);
	s.src = "//s.union.360.cn/" + f + ".js";
	s.defer = !0;
	s.async = !0;
	g.parentNode.insertBefore(s, g);
})(window, document, "script", "_qha", 361707, false);
