$(function() {
	$("body").addClass("mdui-theme-primary-green mdui-theme-accent-red");
})
