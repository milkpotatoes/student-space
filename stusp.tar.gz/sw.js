var cacheName = 'stusp-v1.0.6_3';
var appShellFiles = ["about.html", "exam.html", "index.html", "login.html", "register.html", "unClaim.html",
	"user.html", "404.html",
	"css/style.css", "css/viewer.min.css", "js/base64.js", "js/exam.js", "js/function.js", "js/index.js", "js/login.js",
	"js/NativeShare.js", "js/script.js", "js/showdown.min.js", "js/theme.js", "js/unClaim.js", "js/user.js",
	"js/viewer.min.js", "json/manifest.json", "json/province.json", "json/version.json", "json/import.json",
	"json/grade.json", "md/help.md", "src/1598247557.jpg", "src/3030330.png", "src/6771881.jpeg",
	"src/android-chrome-512x512.png", "src/Android.png", "src/a_edge_12_23.jpg", "src/a_edge_1_1.jpg",
	"src/a_edge_2_1.jpg", "src/a_edge_2_2.jpg", "src/bizelife_1594987651062.jpg", "src/ic_launcher.png",
	"src/ios-share-outline.png", "src/ios.png", "src/i_safari_1.png", "src/i_safari_2.png", "src/i_safari_3.png",
	"src/jquery.ico", "src/mac.png", "src/showdown.png", "src/ubuntu.png", "src/",
	"src/Ultimate Material Lollipop Collection - 456.jpg", "src/viewer.ico", "src/Windows.png", "src/w_edge_12_2.png",
	"src/w_edge_1_1.png", "src/w_edge_2_1.png"
];
// 安装service works.js
self.addEventListener('install', function(e) {
	// console.log('[Service Worker] Install');
	e.waitUntil(
		caches.open(cacheName).then(function(cache) {
			// console.log('[Service Worker] Caching all: app shell and content');
			return cache.addAll(appShellFiles);
		})
	);
});

// Fetching content using Service Worker
// 拦截网络请求已使用本地缓存
self.addEventListener('fetch', function(e) {
	e.respondWith(
		caches.match(e.request).then(function(r) {
			// console.log('[Service Worker] Fetching resource: ' + e.request.url);
			return r || fetch(e.request).then(function(response) {
				if (e.request.url.match(/^(http|https):\/\//) && !e.request.url.match("7net.cc") && !e.request.url.match(
						"hm.baidu.com")) {
					return caches.open(cacheName).then(function(cache) {
						// console.log('[Service Worker] Caching new resource: ' + e.request.url);
						cache.put(e.request, response.clone());
						return response;
					});
				} else {
					return response;
				}
			});
			// } else {
			// return response;
			// }
		})
	);
});

// self.addEventListener('fetch', function(event) {
// 	event.respondWith(caches.match(event.request).then(function(response) {
// 		if (response) {
// 			return response;
// 		}
// 		var requestToCache = event.request.clone();
// 		return fetch(requestToCache).then(function(response) {
// 			if (!response || response.status !== 200) {
// 				return response;
// 			}
// 			var responseToCache = response.clone();
// 			caches.open(CACHE_VERSION).then(function(cache) {
// 				cache.put(requestToCache, responseToCache);
// 			});
// 			return response;
// 		});
// 	}));
// });

self.addEventListener('activate', (e) => {
	e.waitUntil(
		caches.keys().then((keyList) => {
			return Promise.all(keyList.map((key) => {
				if (key !== cacheName) {
					return caches.delete(key);
				}
			}));
		})
	);
});

// this.addEventListener('activate', function(event) {
//   // 声明缓存白名单，该名单内的缓存目录不会被生成
//   // var cacheWhitelist = ['v2'];
//   event.waitUntil(
//     // 传给 waitUntil() 的 promise 会阻塞其他的事件，直到它完成
//     // 确保清理操作会在第一次 fetch 事件之前完成
//     caches.keys().then(function(keyList) {
//       return Promise.all(keyList.map(function(key) {
//         if (cacheWhitelist.indexOf(key) === -1) {
//           return caches.delete(key);
//         }
//       }));
//     })
//   );
// });
